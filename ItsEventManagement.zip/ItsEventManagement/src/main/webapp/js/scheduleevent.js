/**
 * 
 */



$(".event-details").hide();
$(".management-section").hide();
$(".it-section").hide();
function preview(){
	var resource=$('#management-resource').val();
	var count=$('#resource-count').val();
	
	var tr=document.createElement("tr");
	var td1=tr.appendChild(document.createElement('td'));
	var td2=tr.appendChild(document.createElement('td'));
	
	console.log(resource);
	console.log(count);
	
	td1.innerHTML=resource;
	td2.innerHTML=count;
	
	document.getElementById("tb1-preview").appendChild(tr);
}


function itPreview(){
	var resource=$('.it-resource').val();
	var count=$('.it-quantity').val();
	
	var tr=document.createElement("tr");
	var td1=tr.appendChild(document.createElement('td'));
	var td2=tr.appendChild(document.createElement('td'));
	
	console.log(resource);
	console.log(count);
	
	td1.innerHTML=resource;
	td2.innerHTML=count;
	
	document.getElementById("it-table-preview").appendChild(tr);
}

function entrySubmit()
{
	$('.management-section').hide();
	$(".it-section").show();
}

function uploadEventForm(){
	
	var Data=$(this).serialize();
	console.log(Data);
	
	$.ajax({
		url: 'UploadForm',
		data : Data,
		type:'POST',
		
		success:function(data,textStatus,jqXHR){
			itPreview();
			alert("Success")
		},
		error:function(jqXHR,textStatus,errorThrown){
			alert("error");
		}
	})
}

function reDirect() {
	window.location = "event_schedule.jsp";
}

 $(document).ready(function(){

	console.log("hiiiii.......")
	$('.loader-btn').hide();
	$(".event-details").hide();
	$(".management-section").hide();
	$(".it-section").hide();
	
	$("#myform").on('submit',function (event){
		
		$('.submit-btn').hide();
		$('.loader-btn').show();
		
		event.preventDefault();
		var f=$(this).serialize();
		
		console.log(f);
		
		
		$.ajax({
			url: "check",
			data: f,
			type:'POST',
			success:function(data,textStatus,jqXHR){
				console.log(data);
				console.log("success........")
				
				if(data.trim() === 'free'){
					$('#msg').html("Hall is free. <br> You can book....")
					$('.submit-btn').hide();
					$('.loader-btn').hide();
					$(".event-details").show();
					$(".event-schedule").hide();
					console.log(data);
					console.log("Hall is free");
				}
				else{
					$('#msg').html(data);
					console.log("Hall is not free");
					$('.loader-btn').hide();
					$('.submit-btn').show();
				}
			},
			error:function(jqXHR,textStatus,errorThrown){
				console.log(data);
				console.log("error......")
				$('#msg').html("error, something went wrong")
				$('#msg').addClass('red-text')
			}
		})
	});
	
	$("#event-form").on('submit',function (event){
		console.log("all ok");
		event.preventDefault();
		var title=$(this).serialize();
		console.log(title);
		
		$.ajax({
			url: "EventHead",
			data: title,
			type:'POST',
			success:function(data,textStatus,jqXHR){
				$(".event-details").hide();
				$(".management-section").show();
				alert("success");
			},
			error:function(jqXHR,textStatus,errorThrown){
				console.log("failure")
				alert("fail");
			}
		})
	});
	
	$("#entry-preview").on('submit',function (event){
		event.preventDefault();
		console.log("Resource management");
		
		var Data=$(this).serialize();
		console.log(Data);
		
		$.ajax({
			url:'ManagementResource',
			data:Data,
			type:'POST',
			success:function(data,textStatus,jqXHR){
				preview();
				alert("success");
			},
			error:function(jqXHR,textStatus,errorThrown){
				console.log("failure")
				alert("fail");
			}
		})
		
	});
	
	$('#it-entry').on('submit',function (event){
		event.preventDefault();
		
		var Data=$(this).serialize();
		console.log(Data);
		
		$.ajax({
			url: 'ItResource',
			data : Data,
			type:'POST',
			
			success:function(data,textStatus,jqXHR){
				itPreview();
				alert("Success")
			},
			error:function(jqXHR,textStatus,errorThrown){
				alert("error");
			}
		})
	});
	
})