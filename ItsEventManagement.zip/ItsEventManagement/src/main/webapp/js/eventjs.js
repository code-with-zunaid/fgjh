/**
 * 
 */

 
 $(document).ready(function(){
	
	console.log("done.......")
	$('.loader-btn').hide();
	$('.event-schedule').hide();
	
	$("#myform").on('submit',function (event){
		event.preventDefault();
		$('.submit-btn').hide();
		$('.loader-btn').show();
		
		var f=$(this).serialize();
		
		console.log(f);
		
		
		$.ajax({
			url: "ScheduleCheck",
			data: f,
			type:'POST',
			success:function(data,textStatus,jqXHR){
				console.log(data);
				console.log("success........")
				
				
				
				if(data.trim() === 'free'){
					$('#msg').html("Hall is free. <br> You can book....")
					$('.submit-btn').hide();
					$('.loader-btn').hide();
				}
				else{
					$('#msg').html(data);
					$('.loader-btn').hide();
					$('.submit-btn').show();
				}
			},
			error:function(jqXHR,textStatus,errorThrown){
				console.log(data);
				console.log("error......")
				$('#msg').html("error, something went wrong")
				$('#msg').addClass('red-text')
			}
		})
	})
})