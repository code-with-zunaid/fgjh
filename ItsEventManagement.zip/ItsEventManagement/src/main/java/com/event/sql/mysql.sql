-- Create the schedule table

CREATE DATABASE itsEvent;

CREATE TABLE itsEvent.schedule (
  schedule_id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  event_date DATE NOT NULL,
  hall VARCHAR(30) NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL
);

-- Create the event_title table
CREATE TABLE itsEvent.event_title (
  event_id INT PRIMARY KEY AUTO_INCREMENT,
  event_title VARCHAR(50) NOT NULL,
  guests_count INT,
  schedule_id INT,
  FOREIGN KEY (schedule_id) REFERENCES schedule(schedule_id)
);

-- Create the management table
CREATE TABLE itsEvent.management (
  management_id INT PRIMARY KEY AUTO_INCREMENT,
  items TEXT  NOT NULL,
  quantity INT  NOT NULL,
  schedule_id INT  NOT NULL,
  FOREIGN KEY (schedule_id) REFERENCES schedule(schedule_id)
);

-- Create the it_requirement table
CREATE TABLE itsEvent.it_requirement (
  requirement_id INT PRIMARY KEY AUTO_INCREMENT,
  items TEXT NOT NULL,
  quantity INT NOT NULL,
  schedule_id INT  NOT NULL,
  FOREIGN KEY (schedule_id) REFERENCES schedule(schedule_id)
);

-- Create the status table
CREATE TABLE itsEvent.status (
	status_id INT PRIMARY KEY AUTO_INCREMENT,
	schedule_status VARCHAR(20) NOT NULL DEFAULT 'pending',
	management_status VARCHAR(20) NOT NULL DEFAULT 'pending',
	it_status VARCHAR(20) NOT NULL DEFAULT 'pending',
	schedule_id INT,
	FOREIGN KEY (schedule_id) REFERENCES schedule(schedule_id)
);

ALTER TABLE schedule AUTO_INCREMENT=1000;

CREATE TABLE itsEvent.admin_profile(
	id INT AUTO_INCREMENT,
	name varchar(60) NOT NULL,
	email varchar(60) NOT NULL,
	password varchar(30) NOT NULL,
	contact varchar(15),
	about varchar(255),
	dob DATE,
	gender varchar(10),
	profile varchar(255) DEFAULT 'profile.jpg',
	PRIMARY KEY(id)
);

CREATE TABLE itsEvent.it_user(
	id INT AUTO_INCREMENT,
	name varchar(60) NOT NULL,
	email varchar(60) NOT NULL,
	password varchar(30) NOT NULL,
	contact varchar(15),
	about varchar(255),
	dob DATE,
	gender varchar(10),
	profile varchar(255) DEFAULT 'profile.jpg',
	PRIMARY KEY(id)
);

CREATE TABLE itsEvent.management_user(
	id INT AUTO_INCREMENT,
	name varchar(60) NOT NULL,
	email varchar(60) NOT NULL,
	password varchar(30) NOT NULL,
	contact varchar(15),
	about varchar(255),
	dob DATE,
	gender varchar(10),
	profile varchar(255) DEFAULT 'profile.jpg',
	PRIMARY KEY(id)
);

CREATE TABLE itsEvent.user(
	id INT AUTO_INCREMENT,
	name varchar(60) NOT NULL,
	email varchar(60) NOT NULL,
	password varchar(30) NOT NULL,
	contact varchar(15),
	about varchar(255),
	dob DATE,
	gender varchar(10),
	profile varchar(255) DEFAULT 'profile.jpg',
	PRIMARY KEY(id)
);