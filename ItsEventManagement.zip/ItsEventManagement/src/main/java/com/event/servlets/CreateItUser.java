package com.event.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.dao.ItUserDao;
import com.event.entities.ItUser;
import com.event.helper.Message;

/**
 * Servlet implementation class CreateItUser
 */
@WebServlet("/CreateItUser")
public class CreateItUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateItUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ItUser user=new ItUser();
		user.setName(request.getParameter("name"));
		user.setEmail(request.getParameter("email"));
		user.setPassword(request.getParameter("password"));
		user.setContact(request.getParameter("contact"));	
		user.setAbout(request.getParameter("about"));
		user.setDob(request.getParameter("dob"));
		user.setGender(request.getParameter("gender"));
		
		System.out.println(user.getName());
		System.out.println(user.getEmail());
		System.out.println(user.getPassword());
		System.out.println(user.getAbout());
		System.out.println(user.getContact());
		System.out.println(user.getDob());
		System.out.println(user.getGender());
		
		ItUserDao userDao=new ItUserDao();
		HttpSession session=request.getSession();
		boolean flag=userDao.createNewItUser(user);
		if(flag) {
			Message msg=new Message("Account created successfully", "account", "alert-success");
			session.setAttribute("msg", msg);
		}else {
			Message msg=new Message("Something went wrong....   Account created fail", "account", "alert-danger");
			session.setAttribute("msg", msg);
		}
		response.sendRedirect("admin_home.jsp");
	}

}
