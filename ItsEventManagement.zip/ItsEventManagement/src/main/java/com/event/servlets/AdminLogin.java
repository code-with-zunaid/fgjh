package com.event.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.dao.AdminDao;
import com.event.entities.Admin;
import com.event.helper.Message;

/**
 * Servlet implementation class AdminLogin
 */
@WebServlet("/AdminLogin")
public class AdminLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		
		AdminDao dao=new AdminDao();
		
		Admin user=dao.getUserByEmailAndPassword(email, password);
		HttpSession session=request.getSession();
		if(user != null)
		{
			
			
			session.setAttribute("currentUser", user);
			response.sendRedirect("admin_home.jsp");
		}
		else
		{
			System.out.println("admin found as null");
			Message msg=new Message("Invalid user....", "user", "alert-danger");
			session.setAttribute("msg", msg);
			response.sendRedirect("admin_home.jsp");
		}
		
		
	}

}
