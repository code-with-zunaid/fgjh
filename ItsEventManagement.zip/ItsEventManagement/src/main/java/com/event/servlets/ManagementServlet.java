package com.event.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.entities.Management;


/**
 * Servlet implementation class ManagementServlet
 * 
 * 	This servlet is used to store user inputed data during the time of entry of a new event
 */
@WebServlet("/ManagementResource")
public class ManagementServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String item=request.getParameter("resource");
		String quantity=request.getParameter("count");
		
		System.out.println("\nManagement sectio start.......");
		HttpSession session=request.getSession();
		List<Management> list=(List<Management>) session.getAttribute("currentList");
		if(list == null) {
			System.out.println(list);
			list=new ArrayList<Management>();
		}
		else {
			System.out.println("List size : "+list.size());
			System.out.println("Previous data : ");
			Management temp=new Management();
			
			for(int i=0 ; i<list.size() ; i++) {
				temp=list.get(i);
				System.out.println("Resource : "+temp.getItems()+" Quantity : "+temp.getQuantity());
				System.out.println();
			}
		}
		
		Management data=new Management();
		data.setItems(item);
		data.setQuantity(quantity);
		list.add(data);
		
		session.setAttribute("currentList", list);
			
		System.out.println("Resource : "+item);
		System.out.println("Quantity : "+quantity);
		System.out.println("Management section end ................\n");
		
		
	}

	

}
