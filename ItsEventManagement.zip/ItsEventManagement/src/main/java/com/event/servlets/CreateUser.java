package com.event.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.dao.UserDao;
import com.event.entities.User;
import com.event.helper.Message;
import com.event.helper.SendMail;

/**
 * Servlet implementation class CreateUser
 */
@WebServlet("/CreateUser")
public class CreateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter printWriter=response.getWriter();

		
		HttpSession session=request.getSession();
		User user=(User)session.getAttribute("pendingUser");
		String otp=(String)session.getAttribute("otp");
		
		String myotp=request.getParameter("otp");
		
		if(otp.equalsIgnoreCase(myotp))
		{
			System.out.println("Validation success");
			UserDao dao=new UserDao();
			boolean flag=dao.createNewUser(user);
			if(flag) { 
				Message msg=new Message("Account created successfully", "account", "alert-success");
				session.setAttribute("msg", msg);
			}else {
				Message msg=new Message("Something went wrong....   Account created fail", "account", "alert-danger");
				session.setAttribute("msg", msg);
			}
			response.sendRedirect("admin_home.jsp");
		}
		else
		{
			System.out.println("Validation fail");
			Message msg=new Message("Account created fail(Invalid OTP)", "account", "alert-danger");
			session.setAttribute("msg", msg);
			response.sendRedirect("admin_home.jsp");
		}
			
		
		
		
		
		
		
	}

}
