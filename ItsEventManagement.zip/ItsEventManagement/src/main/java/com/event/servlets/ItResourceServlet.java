package com.event.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.entities.ItDepartment;

/**
 * Servlet implementation class ItResourceServlet
 */
@WebServlet("/ItResource")
public class ItResourceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
@SuppressWarnings("unchecked")
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String resource=request.getParameter("resource");
		String quantity=request.getParameter("quantity");
		System.out.println("\nIt section start............");
		System.out.println(" resource : "+resource+" quantity : "+quantity);
		System.out.println("Working properly");
		
		HttpSession session=request.getSession();
		ItDepartment it=new ItDepartment(resource,quantity);
		
		List<ItDepartment> list=(List<ItDepartment>) session.getAttribute("currentItList");
		
		if(list == null) {
			list=new ArrayList<>();
		}else {
			System.out.println("List length : "+list.size());
		}
		
		list.add(it);
		
		session.setAttribute("currentItList", list);
		System.out.println("Done............");
		System.out.println("it section end .............\n");
		
	}

}
