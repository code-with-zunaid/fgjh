package com.event.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.dao.*;
import com.event.entities.*;

/**
 * Servlet implementation class UploadEventServlet
 */
@WebServlet("/UploadForm")
public class UploadEventServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		System.out.println("\n Uploading form data.........");
		Schedule schedule=(Schedule) session.getAttribute("currentSchedule");
		Event event=(Event)session.getAttribute("currentEvent");
		@SuppressWarnings("unchecked")
		List<ItDepartment> itList=(List<ItDepartment>) session.getAttribute("currentItList");
		@SuppressWarnings("unchecked")
		List<Management> management=(List<Management>) session.getAttribute("currentList");
		
		System.out.println("It resource count : "+itList.size());
		System.out.println("Management resurce count : "+management.size());
		
		ScheduleDao schdao=new ScheduleDao();
		boolean flag=schdao.uploadSchedule(schedule);
		if(flag)
		{
			System.out.println("Schedule upload success");
			
			schedule=schdao.getSchedule(schedule);
			System.out.println("Schedule id : "+schedule.getSchedule_id());
			event.setSchedule_id(schedule.getSchedule_id());
			
			EventDao edao=new EventDao();
			
			flag=edao.uploadEvent(event);
			if(flag)
				System.out.println("Event successfully uploaded......");
			Management mgmt=null;
			ManagementDao mdao=new ManagementDao();
			for(int i=0 ; i<management.size() ; i++)
			{
				mgmt=management.get(i);
				mgmt.setSchedule_id(schedule.getSchedule_id());
				mdao.uploadData(mgmt);
			}
			
			System.out.println("Management requirement uploaded successfully");
			ItDepartment it=null;
			ItDao itdao=new ItDao();
			for(int i=0 ; i<itList.size() ; i++)
			{
				it=itList.get(i);
				it.setSchedule_id(schedule.getSchedule_id());
				itdao.uploadData(it);
				
			}
			
			System.out.println("IT requirement uploaded successfully");
			
			Status status=new Status();
			
			status.setSchedule_id(schedule.getSchedule_id());
			StatusDao sdao=new StatusDao();
			
			flag=sdao.uploadData(status);
			if(flag)
				System.out.println("Status uploaded successfully");
			
			
			PrintWriter out=response.getWriter();
			
			response.setContentType("text/html");
			
			out.print("<h1>"
					+ "your event id is "+schedule.getSchedule_id()+"</h1><br>");
			out.print("<p>You can track you request status using this is and event date</p>");
			response.setHeader("Refresh", "10; URL=user_home.jsp");
			
			
			
			
		}
	}

}
