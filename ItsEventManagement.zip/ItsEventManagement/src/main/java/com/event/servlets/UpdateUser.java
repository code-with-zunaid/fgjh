package com.event.servlets;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.event.dao.UserDao;
import com.event.entities.User;
import com.event.helper.Helper;
import com.event.helper.Message;

/**
 * Servlet implementation class UpdateUser
 */
@WebServlet("/updateuser")
@MultipartConfig
public class UpdateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	@SuppressWarnings("deprecation")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String name=request.getParameter("user_name");
		String email=request.getParameter("user_email");
		String password=request.getParameter("user_password");
		String contact=request.getParameter("contact");
		String dob=request.getParameter("user_dob");
		String gender=request.getParameter("gender");
		String about=request.getParameter("about");
		System.out.println(name);
		System.out.println(email);
		System.out.println(password);
		System.out.println(contact);
		System.out.println(dob);
		System.out.println(about);
		
		
		Part part=request.getPart("image");
		
		String profile=part.getSubmittedFileName();
		
		if(part == null)
			System.out.println("Profile picture is null\n\n\n\n\n");
		
		HttpSession session=request.getSession();
		
		User user=(User) session.getAttribute("currentUser");
		if(gender == null)
		{
			gender=user.getGender();
		}
		user.setName(name);
		user.setAbout(about);
		user.setContact(contact);
		user.setDob(dob);
		user.setEmail(email);
		user.setGender(gender);
		user.setPassword(password);
		user.setProfile(profile);
		
		System.out.println("Profile is : "+user.getProfile());
		
		UserDao dao=new UserDao();
		
		boolean flag=dao.updateUser(user);
		
		if(flag)
		{
			Message msg=null;
			System.out.println("updated successfully");
			out.print("updated successfully");
			
			String path=request.getRealPath("/")+"pics"+File.separator+user.getProfile();
			System.out.println(path);
			
			Helper.deleteFile(path);
			
			if(Helper.saveFile(part.getInputStream(), path))
			{
				System.out.println("Profile pic saved successfully");
				out.print("<br>Profile pic uploaded successfully");
				
			}
			else {
				System.out.println("Profile pic not saved");
				out.println("Profile pic not saved");
			}
			msg=new Message("profile updated successfully", "success", "alert-success");
			session.setAttribute("msg", msg);
			session.setAttribute("currentUser", user);
			response.sendRedirect("user_home.jsp");
		}
		else {
			System.out.println("Profile not updated");
			out.println("Profile not updated");
		}
		
		
	}

}
