package com.event.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.dao.ManagementDao;
import com.event.entities.ManagementUser;
import com.event.helper.Message;

/**
 * Servlet implementation class ManagementLoginServlet
 */
@WebServlet("/ManagementLogin")
public class ManagementLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		
		ManagementDao dao=new ManagementDao();
		HttpSession session=request.getSession();
		session.removeAttribute("managementUser");
		Message msg=null;
		ManagementUser user=dao.getUserByEmailAndPassword(email, password);
		
		if(user==null)
		{
			out.print("Invalid user");
			msg=new Message("Login fail.......", "it_user login", "alert-danger");
		}
		else {
			msg=new Message("Login fail.......", "it_user login", "alert-danger");
			session.setAttribute("currentUser", user);
			out.print("Login success");
		}
		session.setAttribute("msg", msg);
		
		response.sendRedirect("management_home.jsp");
	}

}
