package com.event.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.dao.ScheduleDao;
import com.event.entities.Schedule;
import com.event.entities.User;

/**
 * Servlet implementation class CheckAvailablity
 */
@WebServlet("/check")
public class CheckAvailablity extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		Schedule head=new Schedule();
		head.setSchedule_id(null);
		head.setDate(request.getParameter("date"));
		head.setStartTime(request.getParameter("stime"));
		head.setEndTime(request.getParameter("etime"));
		head.setHall(request.getParameter("hall"));
		
		HttpSession session=request.getSession();
		
		User user=(User)session.getAttribute("currentUser");
		head.setUser_id(user.getId()+"");
		
		
		session.removeAttribute("currentSchedule");
		session.removeAttribute("currentItList");
		session.removeAttribute("currentEvent");
		session.removeAttribute("currentList");
		
		int currentStart=0;
		int currentEnd=0;
		int start=0;
		int end=0;
		System.out.println(head.getEndTime());
		String tmp="";
		
		for(int i=0 ; head.getStartTime().charAt(i) != ':' ; i++) {
			tmp=tmp+head.getStartTime().charAt(i);
		}
		currentStart=Integer.parseInt(tmp);
		tmp="";
		for(int i=0 ; head.getEndTime().charAt(i) != ':' ; i++) {
			tmp=tmp+head.getEndTime().charAt(i);
		}
		currentEnd=Integer.parseInt(tmp);
		
		System.out.println("Current : "+currentStart+"  to "+currentEnd);
		
		currentEnd+=1;
		currentStart-=1;
		System.out.println("Updated current : "+currentStart+"  to "+currentEnd);
		PrintWriter out=response.getWriter();
		
		ScheduleDao dao=new ScheduleDao();
		Schedule dbSchedule=new Schedule();
		
		dbSchedule=dao.isAvailable(head);
		if(dbSchedule != null)
		{
			System.out.println("from database start : "+dbSchedule.getStartTime()+" End time : "+dbSchedule.getEndTime());
				
			tmp="";
			for (int i = 0; dbSchedule.getStartTime().charAt(i) != ':' ; i++) {
				tmp=tmp+dbSchedule.getStartTime().charAt(i);
			}
			start =Integer.parseInt(tmp);
			tmp="";
			for(int i=0 ; dbSchedule.getEndTime().charAt(i) != ':' ; i++) {
				tmp=tmp+dbSchedule.getEndTime().charAt(i);
			}
			end=Integer.parseInt(tmp);
			
			System.out.println("Current : from "+currentStart+" to "+currentEnd);
			System.out.println("From database : from "+start+" to "+end);
			
			if(end<=currentStart || start >= currentEnd)
			{
				out.print("free");
				System.out.println("Hall is free");
			}else {
				out.print("Hall is not free<br>An event at "+dbSchedule.getStartTime()+"  "+dbSchedule.getEndTime()+"<br> Please refresh the page.");
				System.out.println("Hall is not free<br>An event at "+dbSchedule.getStartTime()+"  "+dbSchedule.getEndTime()+"<br> Please refresh the page.");
				
			}
	
		}
		else {
			
			session.setAttribute("currentSchedule", head);
			out.print("free");
		}
	}

}
