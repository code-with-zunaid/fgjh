package com.event.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.event.entities.ItDepartment;
import com.event.helper.Dbcon;
import com.event.other.MiniList;


public class ItDao {
	private Connection con;
	{
		con=Dbcon.getConnection();
	}
	
	public boolean uploadData(ItDepartment it)
	{
		boolean flag=false;
		try {
			String query="insert into it_requirement(items,quantity,schedule_id) values(?,?,?)";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, it.getItems());
			ps.setString(2, it.getQuantity());
			ps.setString(3, it.getSchedule_id());
			
			ps.executeUpdate();
			flag=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return flag;
	}
	
	public List<ItDepartment> getResourceById(String id)
	{
		List<ItDepartment> list=new ArrayList<>();
		
		try {
			String query="select * from it_requirement where schedule_id=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, id);
			
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				ItDepartment it=new ItDepartment();
				
				it.setItems(rs.getString("items"));
				it.setQuantity(rs.getString("quantity"));
				it.setRequirement_id(rs.getString("requirement_id"));
				it.setSchedule_id(id);
				list.add(it);
				
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return list;
	}
	
	public boolean isApproved(String id) {
		String query="select it_status from status where schedule_id=?";
		String status=null;
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, id);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
				status=rs.getString("it_status");
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println("isApproved method : "+status);
		return status.equalsIgnoreCase("approved");
	}
	
	public void grantResource(String id)
	{
		try {
			Connection con=Dbcon.getConnection();
			String query="update status set it_status=\"approved\" where schedule_id=?;";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, id);
			
			ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public List<MiniList> getPendingListByUserMode(String userMode){
		
		Connection con=Dbcon.getConnection();
		List<MiniList> list=new ArrayList<>();
		List<String> ids=EventDao.getIdByUserType(userMode);
		try{
			String query="select schedule.schedule_id,event_date,event_title FROM schedule INNER JOIN event_title WHERE schedule.schedule_id=event_title.schedule_id AND schedule.schedule_id=? AND event_date>=CURDATE()";
			
			for(int i=0;i<ids.size() ; i++){
		//		System.out.println("user_id : "+id+" status : "+status+" ids : "+ids.get(i));
				//String query="select schedule.schedule_id,event_date,event_title FROM schedule INNER JOIN event_title WHERE schedule.schedule_id=event_title.schedule_id AND schedule.schedule_id=? AND user_id=? AND event_date>=CURDATE()";
				PreparedStatement ps=con.prepareStatement(query);
				ps.setString(1, ids.get(i));
				
				ResultSet rs=ps.executeQuery();
				if(rs.next()){
					MiniList ms=new MiniList();
					ms.setId(rs.getString("schedule_id"));
					ms.setDate(rs.getString("event_date"));
					ms.setTitle(rs.getString("event_title"));
					list.add(ms);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return list;
	}
	
	

}
