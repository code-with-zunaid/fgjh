package com.event.dao;

import java.sql.Connection;

import com.event.helper.Dbcon;

public class PendingDetails {
	Connection con=null;
	public PendingDetails() {
		// TODO Auto-generated constructor stub
		if(con == null) {
			con=Dbcon.getConnection();
		}
	}
	
//	public pendingList(String query) {
//		
//		try {
//			PreparedStatement ps=con.prepareStatement(query);
//		}
//		catch (Exception e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//		
//	}

}
