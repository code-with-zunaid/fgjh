package com.event.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.event.entities.Schedule;
import com.event.helper.Dbcon;


public class ScheduleDao {
	
	private Connection con=null;
	{
		con=Dbcon.getConnection();
	}
	
	public Schedule isAvailable(final Schedule schedule)
	{
		Schedule newSchedule=null;
		
		try {
			String query="select * from schedule where event_date=? and hall=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1,schedule.getDate());
			ps.setString(2, schedule.getHall());
			
			ResultSet rs=ps.executeQuery();
			
			if(rs.next())
			{
				newSchedule=new Schedule();
				newSchedule.setSchedule_id(rs.getString("schedule_id"));
				newSchedule.setHall(rs.getString("hall"));
				newSchedule.setDate(rs.getString("event_date"));
				newSchedule.setStartTime(rs.getString("start_time"));
				newSchedule.setEndTime(rs.getString("end_time"));;
			}
			
		} catch (Exception e) {
			newSchedule=null;
			System.out.println("Something went wrong "+e);
			e.printStackTrace();
		}
		
		return newSchedule;
	}
	
	public final boolean uploadSchedule(Schedule schedule)
	{
		boolean flag=false;
		
		try {
			String query="insert into schedule(event_date,hall,start_time,end_time,user_id) values(?,?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, schedule.getDate());
			ps.setString(2, schedule.getHall());
			ps.setString(3, schedule.getStartTime());
			ps.setString(4, schedule.getEndTime());
			ps.setString(5, schedule.getUser_id());
			
			ps.execute();
			flag=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public Schedule getSchedule(Schedule schedule)
	{
		Schedule sch=new Schedule();
		
		try {
			
			String query="select * from schedule where event_date=? and hall=? and start_time=? and end_time=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, schedule.getDate());
			ps.setString(2, schedule.getHall());
			ps.setString(3, schedule.getStartTime());
			ps.setString(4, schedule.getEndTime());
			
			ResultSet rs=ps.executeQuery();
			
			if(rs.next())
			{
				sch.setDate(rs.getString("event_date"));
				sch.setSchedule_id(rs.getString("schedule_id"));
				sch.setStartTime(rs.getString("start_time"));
				sch.setEndTime(rs.getString("end_time"));
				sch.setHall(rs.getString("hall"));
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return sch;
	}
	
	public Schedule getScheduleByIdAndDate(String id,String date) {
		Schedule schedule=null;
		
		try {
			String query="select * from schedule where schedule_id=? and event_date=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, id);
			ps.setString(2, date);
			
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				schedule=new Schedule();
				
				schedule.setSchedule_id(id);
				schedule.setStartTime(rs.getString("start_time"));
				schedule.setEndTime(rs.getString("end_time"));
				schedule.setHall(rs.getString("hall"));
				schedule.setDate(rs.getString("event_date"));
				schedule.setUser_id(rs.getString("user_id"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return schedule;
	}
	
	public Schedule getScheduleById(String id) {
		Schedule schedule=null;
		
		try {
			String query="select * from schedule where schedule_id=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, id);
			
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				schedule=new Schedule();
				
				schedule.setSchedule_id(id);
				schedule.setStartTime(rs.getString("start_time"));
				schedule.setEndTime(rs.getString("end_time"));
				schedule.setHall(rs.getString("hall"));
				schedule.setDate(rs.getString("event_date"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return schedule;
	}

}
