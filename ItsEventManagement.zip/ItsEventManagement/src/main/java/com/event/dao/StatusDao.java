package com.event.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.event.entities.Status;
import com.event.helper.Dbcon;


public class StatusDao {
	private Connection con;
	{
		con=Dbcon.getConnection();
	}
	public boolean uploadData(Status status)
	{
		boolean flag=false;
		
		try {
			String query="insert into status(schedule_id) values(?)";
			
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, status.getSchedule_id());
			ps.executeUpdate();
			flag=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public Status getStatusById(String schedule_id)
	{
		Status status=null;
		
		try {
			String query="select * from status where schedule_id=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, schedule_id);
			
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				status=new Status();
				status.setStatus_id(rs.getString("status_id"));
				status.setSchedule_status(rs.getString("schedule_status"));
				status.setManagement_status(rs.getString("management_status"));
				status.setIt_status(rs.getString("it_status"));
				status.setSchedule_id(schedule_id);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return status;
	}
}
