package com.event.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.event.entities.Event;
import com.event.entities.Schedule;
import com.event.helper.Dbcon;
import com.event.other.MiniList;

public class EventDao {
	private static Connection con;
	
	static {
		con=Dbcon.getConnection();
	}
	
	public boolean uploadEvent(Event event) {
		boolean flag=false;
		
		try {
			String query="insert into event_title(event_title,guests_count,schedule_id) values(?,?,?)";
			PreparedStatement ps=con.prepareStatement(query);
			
			ps.setString(1, event.getEvent_title());
			ps.setString(2, event.getGuests_count());
			ps.setString(3, event.getSchedule_id());
			
			ps.executeUpdate();
			flag=true;
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return flag;
	}
	
	public Event getEventById(String schedule_id) {
		Event event=null;
		
		try {
			String query="select * from event_title where schedule_id=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, schedule_id);
			
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				event=new Event();
				event.setEvent_id(rs.getString("event_id"));
				event.setEvent_title(rs.getString("event_title"));
				event.setGuests_count(rs.getString("guests_count"));
				event.setSchedule_id(schedule_id);
			}
		} catch (Exception e) {
			
		}
		return event;
	}
	
	public final Schedule getScheduleById( String id) {
		Schedule schedule=null;
		
		
		
		return schedule;
	}
	
	protected static List<String> getIdByUserType(String userType) {
		
		String query=null;
		Connection con=Dbcon.getConnection();
		List<String> list=new ArrayList<>();
	
		if(userType.equalsIgnoreCase("it")){
			query="select schedule_id from status where it_status=?";
		}else{
			query="select schedule_id from status where management_status=?";
		}
		
		try{
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, "pending");
			ResultSet set=ps.executeQuery();
			while(set.next()){
				String id=set.getString(1);
				list.add(id);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
		System.out.println("list size : "+list.size());
		
		return list;
	}
	
	protected List<String> getIdByStatus(String status){
		Connection con=Dbcon.getConnection();
		List<String> pending=new ArrayList<>();
		String query=null;
		
		if(status.equalsIgnoreCase("pending"))
			query="select schedule_id from status where schedule_status=? OR management_status=? OR it_status=?";
		if(status.equalsIgnoreCase("approved"))
			query="select schedule_id from status where schedule_status=? AND management_status=? AND it_status=?";
			
		try{
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, status);
			ps.setString(2, status);
			ps.setString(3, status);
			
			ResultSet rs=ps.executeQuery();
			System.out.println("........................");
			while(rs.next()){
				String id=rs.getString("schedule_id");
				pending.add(id);
				
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return pending;
	}
	
	public List<MiniList> getListForUserByIdAndStatus(String id,String status){
		List<MiniList> list=new ArrayList<>();
		Connection con=Dbcon.getConnection();
		List<String> ids=getIdByStatus(status);
		
		try{
			System.out.println("Size : "+ids.size());
			for(int i=0;i<ids.size() ; i++){
		//		System.out.println("user_id : "+id+" status : "+status+" ids : "+ids.get(i));
				String query="select schedule.schedule_id,event_date,event_title FROM schedule INNER JOIN event_title WHERE schedule.schedule_id=event_title.schedule_id AND schedule.schedule_id=? AND user_id=? AND event_date>=CURDATE()";
				PreparedStatement ps=con.prepareStatement(query);
				ps.setString(1, ids.get(i));
				ps.setString(2, id);
				ResultSet rs=ps.executeQuery();
				boolean flag=rs.next();
				System.out.println("flag:"+flag);
				if(flag){
					MiniList ms=new MiniList();
					ms.setId(rs.getString("schedule_id"));
					ms.setDate(rs.getString("event_date"));
					ms.setTitle(rs.getString("event_title"));
					list.add(ms);
				}
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return list;
	}
	
	

}
