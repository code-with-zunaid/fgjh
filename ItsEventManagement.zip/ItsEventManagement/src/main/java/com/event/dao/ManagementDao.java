package com.event.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.event.entities.Management;
import com.event.entities.ManagementUser;
import com.event.helper.Dbcon;
import com.event.other.MiniList;


public class ManagementDao {
	
	private Connection con;
	{
		con=Dbcon.getConnection();
	}
	
	/*
	 * 	This method is used to upload Event management resourse 
	 * */
	public boolean uploadData(Management management)
	{
		boolean flag=false;
		try {
			String query="insert into management(items,quantity,schedule_id) values(?,?,?)";
			PreparedStatement ps=con.prepareStatement(query);
			
			ps.setString(1, management.getItems());
			ps.setString(2, management.getQuantity());
			ps.setString(3, management.getSchedule_id());
			
			ps.executeUpdate();
			flag=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public List<Management> getResourceById(String id)
	{
		List<Management> list=new ArrayList<>();
		try {
			String query="select * from management where schedule_id=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, id);
			
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				Management it=new Management();
				
				it.setItems(rs.getString("items"));
				it.setQuantity(rs.getString("quantity"));
				it.setManagement_id((rs.getString("management_id")));
//				System.out.println("item : "+it.getItems()+" unit : "+it.getQuantity());
				

				it.setSchedule_id(id);
				list.add(it);
				
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return list;
	}
	
	public boolean isApproved(String id) {
		String query="select management_status from status where schedule_id=?";
		String status=null;
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, id);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
				status=rs.getString("management_status");
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println("isApproved method : "+status);
		return status.equalsIgnoreCase("approved");
	}
	
	public boolean approveResource(String id) {
		String query="UPDATE status SET management_status=? WHERE schedule_id=?";
		boolean flag=false;
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, "approved");
			ps.setString(2, id);
			int i=ps.executeUpdate();
			if(i>0)
				flag=true;
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return flag;
	}
	
	
	public ManagementUser getUserByEmailAndPassword(String email,String password)
	{
		ManagementUser user=null;
		
		try {
			String query="select * from management_user where email=? and password=?";
			
			PreparedStatement ps=con.prepareStatement(query);
			
			ps.setString(1, email);
			ps.setString(2, password);
			
			ResultSet rs=ps.executeQuery();
			
			if(rs.next())
			{
				user=new ManagementUser();
				user.setId(Integer.parseInt(rs.getString("id")));
				user.setName(rs.getString("name"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				user.setAbout(rs.getString("about"));
				user.setContact(rs.getString("contact"));
				user.setDob(rs.getString("DOB"));
				user.setGender(rs.getString("gender"));
				user.setProfile(rs.getString("profile"));
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return user;
	}
	
	
public List<MiniList> getPendingListByUserMode(String userMode){
		
		Connection con=Dbcon.getConnection();
		List<MiniList> list=new ArrayList<>();
		List<String> ids=EventDao.getIdByUserType(userMode);
		try{
			String query="select schedule.schedule_id,event_date,event_title FROM schedule INNER JOIN event_title WHERE schedule.schedule_id=event_title.schedule_id AND schedule.schedule_id=? AND event_date>=CURDATE()";
			
			for(int i=0;i<ids.size() ; i++){
		//		System.out.println("user_id : "+id+" status : "+status+" ids : "+ids.get(i));
				//String query="select schedule.schedule_id,event_date,event_title FROM schedule INNER JOIN event_title WHERE schedule.schedule_id=event_title.schedule_id AND schedule.schedule_id=? AND user_id=? AND event_date>=CURDATE()";
				PreparedStatement ps=con.prepareStatement(query);
				ps.setString(1, ids.get(i));
				
				ResultSet rs=ps.executeQuery();
				if(rs.next()){
					MiniList ms=new MiniList();
					ms.setId(rs.getString("schedule_id"));
					ms.setDate(rs.getString("event_date"));
					ms.setTitle(rs.getString("event_title"));
					list.add(ms);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return list;
	}

}
