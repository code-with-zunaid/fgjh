package com.event.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.event.entities.ManagementUser;
import com.event.helper.Dbcon;

public class ManagementUserDao {
	Connection con=null;
	public ManagementUserDao() {
		// TODO Auto-generated constructor stub
		if(con == null) {
			con=Dbcon.getConnection();
		}
	}
	
	public boolean CreateNewManagementUser(ManagementUser user) {
		boolean flag=false;
		
		String query="insert into management_user(name,email,password,contact,about,dob,gender) value (?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps= con.prepareStatement(query);
			
			ps.setString(1, user.getName());
			ps.setString(2, user.getEmail());
			ps.setString(3, user.getPassword());
			ps.setString(4, user.getContact());
			ps.setString(5, user.getAbout());
			ps.setString(6, user.getDob());
			ps.setString(7, user.getGender());
			
			int i=ps.executeUpdate();
			if(i != 0)
			{
				flag=true;
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

}
