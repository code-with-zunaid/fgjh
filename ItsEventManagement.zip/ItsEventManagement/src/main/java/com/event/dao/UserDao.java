package com.event.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.event.entities.User;
import com.event.helper.Dbcon;

public class UserDao {
	Connection con=null;
	{
		con=Dbcon.getConnection();
	}
	
	public User getUserById(String id) {
		User user=null;
		
		try {
			String query="select * from user where id=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, id);
			
			ResultSet rs=ps.executeQuery();
			
			if(rs.next()) {
				user=new User();
				
				user.setId(Integer.parseInt(rs.getString("id")));
				user.setName(rs.getString("name"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				user.setAbout(rs.getString("about"));
				user.setContact(rs.getString("contact"));
				user.setDob(rs.getString("DOB"));
				user.setGender(rs.getString("gender"));
				user.setProfile(rs.getString("profile"));
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return user;
	}
	
	public User getUserByEmailAndPassword(String email,String password)
	{
		User user=null;
		
		try {
			String query="select * from user where email=? and password=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, email);
			ps.setString(2, password);
			
			ResultSet rs=ps.executeQuery();
			
			if(rs.next()) {
				user=new User();
				
				user.setId(Integer.parseInt(rs.getString("id")));
				user.setName(rs.getString("name"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				user.setAbout(rs.getString("about"));
				user.setContact(rs.getString("contact"));
				user.setDob(rs.getString("DOB"));
				user.setGender(rs.getString("gender"));
				user.setProfile(rs.getString("profile"));
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}
	
	
	public boolean updateUser(User user) {
		boolean flag=false;
		
		try {
			String query="update user set name=?,email=?,password=?,contact=?,DOB=?,gender=?,about=?,profile=? where id=?";
			
			PreparedStatement ps=con.prepareStatement(query);
			
			ps.setString(1, user.getName());
			ps.setString(2, user.getEmail());
			ps.setString(3, user.getPassword());
			ps.setString(4, user.getContact());
			ps.setString(5, user.getDob());
			ps.setString(6, user.getGender());
			ps.setString(7, user.getAbout());
			ps.setString(8, user.getProfile());
			ps.setString(9, user.getId()+"");
			
			ps.executeUpdate();
			flag=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;	
	}
	
	public boolean createNewUser(User user) {
		boolean flag=false;
		String query="insert into user(name,email,password,contact,about,dob,gender) value (?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement ps= con.prepareStatement(query);
			
			ps.setString(1, user.getName());
			ps.setString(2, user.getEmail());
			ps.setString(3, user.getPassword());
			ps.setString(4, user.getContact());
			ps.setString(5, user.getAbout());
			ps.setString(6, user.getDob());
			ps.setString(7, user.getGender());
			
			int i=ps.executeUpdate();
			if(i != 0)
			{
				flag=true;
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
}
