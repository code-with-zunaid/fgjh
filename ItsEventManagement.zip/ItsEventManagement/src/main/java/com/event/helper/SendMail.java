package com.event.helper;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendMail {
	
	public static boolean sendMail(String email,int message,String subject) {
		boolean flag=false;
		
		
		String host="smtp.gmail.com";
		String userid="raushankumartiwari_mca22_24@its.edu.in";
		String password="Its@drugs";
		
		String to=email;
		String from=userid;
		
		try {
			Properties properties=new Properties();
			properties.put("mail.smtp.host", host);
			properties.put("mail.transport.protocol", "smtps");
			properties.put("mail.smtp.user", userid);
			properties.put("mail.smtp.password", password);
			properties.put("mail.smtp.port", "465");
			properties.put("mail.smtps.auth", "true");
			
			Session session=Session.getDefaultInstance(properties,null);
			MimeMessage mimeMessage=new MimeMessage(session);
			
			InternetAddress fromAddress=null;
			InternetAddress toAddress=null;
			
			fromAddress=new InternetAddress(from);
			toAddress=new InternetAddress(to);
			
			mimeMessage.setFrom(fromAddress);
			mimeMessage.setRecipient(Message.RecipientType.TO, toAddress);
			
			mimeMessage.setSubject(subject);
			
			Multipart body=new MimeMultipart();
			MimeBodyPart part1=new MimeBodyPart();
			
			part1.setText(message+"");
			body.addBodyPart(part1);
			
			mimeMessage.setContent(body);
			
			Transport transport=session.getTransport("smtps");
			System.out.println("transport ok");
			
			transport.connect(host, userid, password);
			System.out.println("connection ok");
			
			transport.sendMessage(mimeMessage, mimeMessage.getAllRecipients());
			transport.close();
			System.out.println("Message sent successfully");
			flag=true;
			
		} catch (Exception e) {
			System.out.println("Something went wrong");
			e.printStackTrace();
		}
		
		
		
		
		return flag;
	}

}
