package com.event.helper;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dbcon {
	private static Connection con=null;
	
	public static Connection getConnection()
	{
		String url="jdbc:mysql://localhost:3306/itsEvent";
		String id="root";
		String pass="Android@test1";
		
		try
		{
			if(con == null)
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				con=DriverManager.getConnection(url,id,pass);
			}
		}
		catch (Exception e) {
			System.out.println("Connection  fail");
			System.out.println(e);
		}
//		System.out.println(con);
		return con;
		
	}

}
