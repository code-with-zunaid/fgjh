package com.event.helper;

public class Message {
	
	private String content;
	private String type;
	private String Style;
	public Message(String content, String type, String cssStyle) {
		super();
		this.content = content;
		this.type = type;
		this.Style = cssStyle;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getStyle() {
		return Style;
	}
	public void setStyle(String cssStyle) {
		this.Style = cssStyle;
	}
	
	

}
