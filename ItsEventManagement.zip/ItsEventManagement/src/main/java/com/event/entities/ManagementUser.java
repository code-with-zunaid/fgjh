package com.event.entities;

public class ManagementUser extends UserAccount{

	public ManagementUser() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ManagementUser(int id, String name, String email, String password, String contact, String about, String dob,
			String gender, String profile) {
		super(id, name, email, password, contact, about, dob, gender, profile);
		// TODO Auto-generated constructor stub
	}

	public ManagementUser(String name, String email, String password, String contact, String about, String dob,
			String gender, String profile) {
		super(name, email, password, contact, about, dob, gender, profile);
		// TODO Auto-generated constructor stub
	}
	
}
