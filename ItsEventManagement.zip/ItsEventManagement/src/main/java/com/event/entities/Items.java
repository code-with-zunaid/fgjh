package com.event.entities;

public class Items {
	
	private String items ;
	private String quantity ;
	private String schedule_id ;
	
	public Items() {
		super();
	}
	
	public Items(String items, String quantity) {
		super();
		this.items = items;
		this.quantity = quantity;
	}
	
	public Items(String items, String quantity, String schedule_id) {
		super();
		this.items = items;
		this.quantity = quantity;
		this.schedule_id = schedule_id;
	}
	
	public String getItems() {
		return items;
	}
	
	public void setItems(String items) {
		this.items = items;
	}
	
	public String getQuantity() {
		return quantity;
	}
	
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	
	public String getSchedule_id() {
		return schedule_id;
	}
	
	public void setSchedule_id(String schedule_id) {
		this.schedule_id = schedule_id;
	}
	
	
}
