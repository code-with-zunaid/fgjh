package com.event.entities;

public class Event {

	private String event_id ;
	private String event_title ;
	private String guests_count ;
	private String schedule_id ;
	
	public Event() {
		super();
	}
	
	public Event(String event_title, String guests_count) {
		super();
		this.event_title = event_title;
		this.guests_count = guests_count;
	}
	
	
	public Event(String event_id, String event_title, String guests_count, String schedule_id) {
		super();
		this.event_id = event_id;
		this.event_title = event_title;
		this.guests_count = guests_count;
		this.schedule_id = schedule_id;
	}
	
	
	public String getEvent_id() {
		return event_id;
	}
	
	
	public void setEvent_id(String event_id) {
		this.event_id = event_id;
	}
	
	
	public String getEvent_title() {
		return event_title;
	}
	
	
	public void setEvent_title(String event_title) {
		this.event_title = event_title;
	}
	
	
	public String getGuests_count() {
		return guests_count;
	}
	
	
	public void setGuests_count(String guests_count) {
		this.guests_count = guests_count;
	}
	
	
	public String getSchedule_id() {
		return schedule_id;
	}
	
	
	public void setSchedule_id(String schedule_id) {
		this.schedule_id = schedule_id;
	}
	
}
