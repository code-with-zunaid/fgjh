package com.event.entities;

public class ItUser extends UserAccount{

	public ItUser() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ItUser(String name, String email, String password, String contact, String about, String dob, String gender) {
		super(name, email, password, contact, about, dob, gender);
		// TODO Auto-generated constructor stub
	}

	public ItUser(int id, String name, String email, String password, String contact, String about, String dob,
			String gender, String profile) {
		super(id, name, email, password, contact, about, dob, gender, profile);
		// TODO Auto-generated constructor stub
	}

	public ItUser(String name, String email, String password, String contact, String about, String dob, String gender,
			String profile) {
		super(name, email, password, contact, about, dob, gender, profile);
		// TODO Auto-generated constructor stub
	}
	
	

}
