package com.event.entities;


public class Admin extends UserAccount{
	

}
