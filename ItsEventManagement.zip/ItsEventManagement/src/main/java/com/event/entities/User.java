package com.event.entities;


public class User extends UserAccount{

	public User() {
		super();
		
	}

	public User(int id, String name, String email, String password, String contact, String about, String dob,
			String gender, String profile) {
		super(id, name, email, password, contact, about, dob, gender, profile);
		// TODO Auto-generated constructor stub
	}

	public User(String name, String email, String password, String contact, String about, String dob, String gender,
			String profile) {
		super(name, email, password, contact, about, dob, gender, profile);
		// TODO Auto-generated constructor stub
	}

	
	
}
