package com.event.entities;

public class Management extends Items{
	
	private String management_id;

	public Management() {
		super();
	}
	
	public Management(String items, String quantity) {
		super(items, quantity);
		
	}

	public Management(String management_id,String items, String quantity, String schedule_id) {
		super(items, quantity, schedule_id);
		
		this.management_id=management_id;
		
	}

	public String getManagement_id() {
		return management_id;
	}

	public void setManagement_id(String management_id) {
		this.management_id = management_id;
	}
	
	

	
	
	

}
