package com.event.entities;

public class ItDepartment extends Items{
	
	private String requirement_id ;
	
	public ItDepartment() {
		super();
	}
	
	public ItDepartment(String items, String quantity) {
		super(items,quantity);
	}
	public ItDepartment(String requirement_id, String items, String quantity, String schedule_id) {
		super(items,quantity,schedule_id);
		this.requirement_id = requirement_id;
	}
	public String getRequirement_id() {
		return requirement_id;
	}
	public void setRequirement_id(String requirement_id) {
		this.requirement_id = requirement_id;
	}
	
	

}
