package com.event.entities;

public class Schedule {
	private String schedule_id ;
	private String user_id;
	private String date;
	private String startTime;
	private String endTime;
	private String hall;
	
	public Schedule() {
		super();
	}
	public Schedule(String date, String startTime, String endTime, String hall) {
		super();
		this.date = date;
		this.startTime = startTime;
		this.endTime = endTime;
		this.hall = hall;
	}
	
	
	
	
	public Schedule(String schedule_id, String date, String startTime, String endTime, String hall) {
		super();
		this.schedule_id = schedule_id;
		this.date = date;
		this.startTime = startTime;
		this.endTime = endTime;
		this.hall = hall;
	}
	public Schedule(String schedule_id, String user_id, String date, String startTime, String endTime, String hall) {
		super();
		this.schedule_id = schedule_id;
		this.user_id = user_id;
		this.date = date;
		this.startTime = startTime;
		this.endTime = endTime;
		this.hall = hall;
	}
	public String getSchedule_id() {
		return schedule_id;
	}
	public void setSchedule_id(String schedule_id) {
		this.schedule_id = schedule_id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getHall() {
		return hall;
	}
	public void setHall(String hall) {
		this.hall = hall;
	}
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	
	
}
