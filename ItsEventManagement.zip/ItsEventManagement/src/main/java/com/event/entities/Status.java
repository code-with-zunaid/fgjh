package com.event.entities;

public class Status {
	
	private String status_id;
	private String schedule_status;
	private String management_status;
	private String it_status;
	private String schedule_id;
	
	public Status() {
		// TODO Auto-generated constructor stub
	}

	public String getStatus_id() {
		return status_id;
	}

	public void setStatus_id(String status_id) {
		this.status_id = status_id;
	}

	public String getSchedule_status() {
		return schedule_status;
	}

	public void setSchedule_status(String schedule_status) {
		this.schedule_status = schedule_status;
	}

	public String getManagement_status() {
		return management_status;
	}

	public void setManagement_status(String management_status) {
		this.management_status = management_status;
	}

	public String getIt_status() {
		return it_status;
	}

	public void setIt_status(String it_status) {
		this.it_status = it_status;
	}

	public String getSchedule_id() {
		return schedule_id;
	}

	public void setSchedule_id(String schedule_id) {
		this.schedule_id = schedule_id;
	}
	
	

}
